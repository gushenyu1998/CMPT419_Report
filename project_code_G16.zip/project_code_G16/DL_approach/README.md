# 724-emotion-speech-synthesis

## Overview

This repository contains the necessary components for the machine learning model handling sound processing. It includes data storage, configuration files, preprocessing and postprocessing functions, as well as model training and validation functionalities.

## Directory Structure

- **ESD folder/**: Contains the dataset used for training and testing the machine learning model.
- **Model Folder/**: Stores the machine learning models, including block structures, transformer mechanisms, and VQ-VAE models.
- **Config.py**: This script contains all the configurations for the model training, including paths, model parameters, and other settings.

## Sound Processing

- **Sound process/**: Includes scripts for sound preprocessing and postprocessing. These functions are crucial for preparing audio data before training and transforming model outputs into a usable format.

## Machine Learning Models

- **Block.py**: Defines the block structure used within the machine learning models.
- **Transformer.py**: Contains the implementation of the transformer model which is used for handling sequences in the sound data.
- **VQ-VAE.py**: Implements the Vector Quantized Variational Autoencoder model for efficient sound data encoding and decoding.

## Training and Validation

- **Training.py**: This script houses functions for model training and validation. To train or validate a model, you can use the following functions:
  - `[model]_train()`: For starting the training process.
  - `[model]_validate()`: For validating the trained model.

## Usage

To start using this repository, ensure that you have all the necessary dependencies installed, then follow these steps:
1. Configure your paths and parameters in `Config.py`.
2. Prepare your sound data using the preprocessing functions in the `Sound process` folder.
3. Train the model by call the vqvae_train() in Train.py or other training method